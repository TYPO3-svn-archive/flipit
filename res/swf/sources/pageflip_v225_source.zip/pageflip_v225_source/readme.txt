Demo
====
  * http://pageflip.hu/pageflip2/index.php

Download
========
  * http://pageflip.hu/pageflip2/pageflip_v225_source.zip

Requirements
============
  * You have to compile the source code by Flash 

Non supported features
======================
  * Navigation bar

 
wildt, http://wildt.at.dienetzmacher.de
2013-01-02

